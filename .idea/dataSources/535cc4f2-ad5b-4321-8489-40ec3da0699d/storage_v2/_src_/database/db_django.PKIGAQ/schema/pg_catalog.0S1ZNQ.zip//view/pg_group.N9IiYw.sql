create view pg_group(groname, grosysid, grolist) as
SELECT rolname                                             AS groname,
       oid                                                 AS grosysid,
       ARRAY(SELECT pg_auth_members.member
             FROM pg_auth_members
             WHERE pg_auth_members.roleid = pg_authid.oid) AS grolist
FROM pg_authid
WHERE NOT rolcanlogin;

alter table pg_group
    owner to postgres;

grant select on pg_group to public;

