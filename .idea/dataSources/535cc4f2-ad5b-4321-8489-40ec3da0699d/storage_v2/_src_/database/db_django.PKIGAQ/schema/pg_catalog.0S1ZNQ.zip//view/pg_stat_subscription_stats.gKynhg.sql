create view pg_stat_subscription_stats(subid, subname, apply_error_count, sync_error_count, stats_reset) as
SELECT ss.subid,
       s.subname,
       ss.apply_error_count,
       ss.sync_error_count,
       ss.stats_reset
FROM pg_subscription s,
     LATERAL pg_stat_get_subscription_stats(s.oid) ss(subid, apply_error_count, sync_error_count, stats_reset);

alter table pg_stat_subscription_stats
    owner to postgres;

grant select on pg_stat_subscription_stats to public;

