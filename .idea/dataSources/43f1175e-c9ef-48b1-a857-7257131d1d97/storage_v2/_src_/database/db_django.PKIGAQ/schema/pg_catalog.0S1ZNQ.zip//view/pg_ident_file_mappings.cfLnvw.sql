create view pg_ident_file_mappings (map_number, file_name, line_number, map_name, sys_name, pg_username, error) as
SELECT map_number,
       file_name,
       line_number,
       map_name,
       sys_name,
       pg_username,
       error
FROM pg_ident_file_mappings() a(map_number, file_name, line_number, map_name, sys_name, pg_username, error);

alter table pg_ident_file_mappings
    owner to postgres;

